/**
 *  @file        imglist-private.h
 *  @description Student-defined functions of ImgList class, for CPSC 221 PA1
 *
 *  THIS FILE WILL BE SUBMITTED.
 *  YOU MAY ADD YOUR OWN PRIVATE MEMBER FUNCTION DECLARATIONS HERE.
 *  IF YOU DO NOT HAVE FUNCTIONS TO ADD, LEAVE THIS BLANK
 */

/**************************************/
/* ADD YOUR PRIVATE DECLARATIONS HERE */
/**************************************/

